# Szczegółowe przypadki użycia

## Gra „Kebab” (symulator prowadzenia nietypowej kebabowni)



### 1\. Przyjmij zamówienie

Aktor główny: Gracz

Aktor drugorzędny: Klient



Cel: Przyjęcie zamówienia od klienta odwiedzającego lokal gastronomiczny i rozpoczęcie procesu przygotowywania kebaba zgodnego z jego wymaganiami.



Warunki wstępne

\- Gracz znajduje się w lokalu, w którym obsługiwani są klienci.

\- Lokal jest otwarty i gotowy do przyjmowania zamówień.

\- W stołówce pojawił się klient zainteresowany zakupem kebaba.

Warunki końcowe (sukces)

\- Zamówienie zostaje przyjęte przez gracza.

\- Gracz otrzymuje informacje o wymaganiach klienta dotyczących kebaba.

\- Zamówienie zostaje dodane do listy aktywnych zadań.

Główny przebieg zdarzeń

1\. Klient pojawia się w stołówce.

2\. Gracz podchodzi do klienta.

3\. Klient przedstawia swoje zamówienie.

4\. System wyświetla wymagania dotyczące zamawianego kebaba.

5\. Gracz zapoznaje się z zamówieniem.

6\. Gracz akceptuje zamówienie.

7\. System zapisuje zamówienie jako aktywne.

8\. Gracz może przejść do kuchni w celu przygotowania potrawy.

Przebiegi alternatywne

\- 2a. Gracz nie podchodzi do klienta – klient oczekuje na obsługę przez określony czas.

\- 3a. Klient zamawia nietypowego kebaba – system wyświetla dodatkowe wymagania dotyczące składników.

\- 5a. Gracz posiada już aktywne zamówienie – może zdecydować o kolejności realizacji zamówień.

Przebiegi wyjątkowe

\- E1. Klient rezygnuje z zamówienia – zamówienie zostaje anulowane.

\- E2. Brak możliwości przyjęcia kolejnego zamówienia – system informuje gracza o konieczności zakończenia aktualnych zadań.

Powiązania z innymi przypadkami użycia

\- «include» Przygotuj kebaba – przyjęcie zamówienia prowadzi do konieczności przygotowania potrawy.

\- «extend» Odkryj nowe składniki – niektóre zamówienia mogą wymagać składników, których gracz jeszcze nie posiada.

Częstotliwość użycia: Bardzo wysoka – przyjmowanie zamówień stanowi podstawowy element rozgrywki.



### 2\. Przygotuj kebaba

Aktor główny: Gracz



Aktor drugorzędny: Brak



Cel: Przygotowanie kebaba zgodnie z zamówieniem klienta poprzez wybór i połączenie odpowiednich składników.



Warunki wstępne

\- Gracz posiada aktywne zamówienie.

\- Gracz znajduje się w kuchni.

\- W kuchni dostępne są składniki potrzebne do przygotowania potrawy.

\- Gracz odblokował wymagane składniki.

Warunki końcowe (sukces)

\- Kebab zostaje przygotowany.

\- System zapisuje wykorzystane składniki.

\- Przygotowana potrawa jest gotowa do przekazania klientowi.

Główny przebieg zdarzeń

1\. Gracz przechodzi do kuchni.

2\. Gracz rozpoczyna przygotowywanie kebaba.

3\. System wyświetla dostępne składniki.

4\. Gracz wybiera odpowiednie składniki.

5\. Gracz umieszcza składniki w przygotowywanym kebabie.

6\. System sprawdza poprawność przygotowywanej potrawy.

7\. Gracz kończy przygotowywanie kebaba.

8\. System zapisuje gotową potrawę.

9\. Gracz otrzymuje możliwość wydania zamówienia klientowi.

Przebiegi alternatywne

\- 3a. Gracz odblokował nowe składniki – pojawiają się one na liście dostępnych produktów.

\- 4a. Gracz wybiera nietypowe składniki – system umożliwia przygotowanie nietypowego połączenia.

\- 6a. Kebab nie odpowiada zamówieniu – system informuje gracza o niezgodności składników.

\- 7a. Gracz zmienia wybrane składniki przed zakończeniem przygotowywania potrawy.

Przebiegi wyjątkowe

\- E1. Brak wymaganego składnika – system informuje gracza o konieczności zdobycia brakującego produktu.

\- E2. Gracz próbuje wykorzystać nieodblokowany składnik – system blokuje możliwość jego użycia.

\- E3. Gracz przerywa przygotowywanie kebaba – proces zostaje anulowany lub pozostaje niedokończony.

Powiązania z innymi przypadkami użycia

\- «include» Przyjmij zamówienie – przygotowanie kebaba jest związane z wcześniej przyjętym zamówieniem.

\- «extend» Odkryj nowe składniki – eksploracja może zapewnić dostęp do nowych produktów.

\- «include» Wydaj zamówienie – po przygotowaniu kebaba możliwe jest przekazanie go klientowi.

Częstotliwość użycia: Bardzo wysoka – przygotowywanie kebabów stanowi główną mechanikę gry.



### 3\. Wydaj zamówienie

Aktor główny: Gracz

Aktor drugorzędny: Klient



Cel: Przekazanie przygotowanego kebaba klientowi i zakończenie procesu realizacji zamówienia.



Warunki wstępne

\- Gracz posiada przygotowanego kebaba.

\- Istnieje aktywne zamówienie przypisane do klienta.

\- Klient nadal znajduje się w lokalu.

\- Potrawa jest gotowa do wydania.

Warunki końcowe (sukces)

\- Kebab zostaje przekazany klientowi.

\- Zamówienie zostaje oznaczone jako zrealizowane.

\- System aktualizuje postęp rozgrywki.

\- Gracz może przejść do realizacji kolejnego zamówienia.

Główny przebieg zdarzeń

1\. Gracz zabiera przygotowanego kebaba z kuchni.

2\. Gracz przechodzi do stołówki.

3\. Gracz odnajduje klienta, który złożył zamówienie.

4\. Gracz przekazuje kebaba klientowi.

5\. System porównuje przygotowaną potrawę z wymaganiami zamówienia.

6\. System określa, czy zamówienie zostało wykonane poprawnie.

7\. Klient otrzymuje zamówioną potrawę.

8\. System oznacza zamówienie jako zakończone.

9\. Gracz może przyjąć kolejne zamówienie.

Przebiegi alternatywne

\- 5a. Kebab zawiera inne składniki niż wymagane – system informuje o niezgodności zamówienia.

\- 6a. Zamówienie zostało wykonane poprawnie – gracz otrzymuje pozytywny wynik realizacji.

\- 6b. Zamówienie zostało wykonane niepoprawnie – klient reaguje niezadowoleniem.

Przebiegi wyjątkowe

\- E1. Klient opuścił lokal przed wydaniem zamówienia – system informuje o nieudanej realizacji.

\- E2. Gracz nie posiada przygotowanego kebaba – system uniemożliwia zakończenie zamówienia.

\- E3. Przygotowana potrawa nie może zostać przekazana klientowi – zamówienie pozostaje niezakończone.

Powiązania z innymi przypadkami użycia

\- «include» Przygotuj kebaba – wydanie zamówienia wymaga wcześniejszego przygotowania potrawy.

\- «extend» Przyjmij zamówienie – wydanie jest końcowym etapem wcześniej przyjętego zamówienia.

Częstotliwość użycia: Bardzo wysoka – wydawanie zamówień jest niezbędne do kontynuowania rozgrywki.



### 4\. Eksploruj lokal i zaplecze

Aktor główny: Gracz



Aktor drugorzędny: Brak



Cel: Swobodne przemieszczanie się po lokalu i jego zapleczu w celu odnajdywania przedmiotów, składników oraz wskazówek związanych z historią kebabowni.



Warunki wstępne

\- Gracz rozpoczął rozgrywkę.

\- Lokal jest dostępny do eksploracji.

\- Gracz może przemieszczać się pomiędzy dostępnymi pomieszczeniami.

Warunki końcowe (sukces)

\- Gracz może odnaleźć nowe przedmioty, składniki lub wskazówki.

\- System zapisuje odkryte elementy.

\- Postęp eksploracji zostaje uwzględniony w stanie rozgrywki.

Główny przebieg zdarzeń

1\. Gracz opuszcza aktualnie zajmowane pomieszczenie.

2\. Gracz wybiera kierunek przemieszczania się.

3\. Gracz przechodzi do wybranego pomieszczenia.

4\. Gracz przeszukuje dostępne obszary.

5\. System wykrywa możliwe do zbadania obiekty.

6\. Gracz podchodzi do wybranego obiektu.

7\. Gracz wchodzi w interakcję z obiektem.

8\. System sprawdza, czy obiekt zawiera przedmiot, składnik lub wskazówkę.

9\. Gracz otrzymuje znaleziony przedmiot lub informację.

10\. System zapisuje odkrycie w postępie rozgrywki.

Przebiegi alternatywne

\- 4a. Gracz odnajduje zamknięte pomieszczenie – system informuje o braku dostępu.

\- 7a. Gracz bada przedmiot związany z historią lokalu – otrzymuje dodatkowe informacje fabularne.

\- 8a. Gracz odnajduje nowy składnik – składnik zostaje dodany do dostępnych zasobów.

\- 9a. Gracz odnajduje przedmiot potrzebny do odblokowania kolejnego obszaru.

Przebiegi wyjątkowe

\- E1. Gracz próbuje wejść do niedostępnego pomieszczenia – system blokuje przejście.

\- E2. Gracz próbuje ponownie zebrać już odnaleziony przedmiot – system informuje, że przedmiot został wcześniej zabrany.

\- E3. Gracz nie spełnia warunków wymaganych do zbadania obiektu – interakcja nie zostaje wykonana.

Powiązania z innymi przypadkami użycia

\- «extend» Odkryj nowe składniki – podczas eksploracji gracz może odnajdywać nowe produkty.

\- «extend» Odkrywaj historię lokalu – odnajdywane przedmioty i wskazówki pozwalają poznawać przeszłość kebabowni.

\- Wpływa na Przygotuj kebaba – odnalezione składniki rozszerzają możliwości przygotowywania potraw.

Częstotliwość użycia: Wysoka – eksploracja pozwala rozwijać rozgrywkę i odkrywać kolejne elementy świata gry.



### 5\. Odkrywaj historię lokalu

Aktor główny: Gracz



Aktor drugorzędny: Brak



Cel: Stopniowe poznawanie tajemnic kebabowni poprzez odnajdywanie wskazówek, badanie przedmiotów oraz wykonywanie określonych zadań.



Warunki wstępne

\- Gracz rozpoczął rozgrywkę.

\- Gracz ma dostęp do przynajmniej części lokalu lub zaplecza.

\- W świecie gry znajdują się przedmioty lub wskazówki związane z historią lokalu.

Warunki końcowe (sukces)

\- Gracz odkrywa nowe informacje dotyczące przeszłości lokalu.

\- System zapisuje odkryte elementy fabularne.

\- Niektóre nowe zadania, składniki lub możliwości mogą zostać odblokowane.

Główny przebieg zdarzeń

1\. Gracz eksploruje dostępne pomieszczenia.

2\. Gracz odnajduje przedmiot lub wskazówkę.

3\. Gracz podchodzi do odnalezionego obiektu.

4\. Gracz rozpoczyna interakcję z obiektem.

5\. System wyświetla informacje związane ze znaleziskiem.

6\. Gracz zapoznaje się z odkrytą treścią.

7\. System zapisuje odkrycie w postępie fabularnym.

8\. System sprawdza, czy gracz spełnił warunki odkrycia kolejnego elementu historii.

9\. W przypadku spełnienia warunków udostępniane są kolejne wskazówki lub zadania.

Przebiegi alternatywne

\- 2a. Gracz odnajduje kilka wskazówek – system zapisuje wszystkie odkryte informacje.

\- 5a. Znalezisko jest powiązane z konkretnym składnikiem – system może odblokować możliwość jego zdobycia.

\- 8a. Gracz nie spełnia jeszcze wszystkich warunków fabularnych – dalsze odkrywanie pozostaje zablokowane.

Przebiegi wyjątkowe

\- E1. Gracz próbuje zbadać niedostępny obiekt – system nie pozwala na interakcję.

\- E2. Gracz próbuje ponownie odkryć tę samą wskazówkę – system informuje, że została już znaleziona.

\- E3. Gracz nie posiada wymaganego przedmiotu – system uniemożliwia kontynuowanie danego odkrycia.

Powiązania z innymi przypadkami użycia

\- «include» Eksploruj lokal i zaplecze – odkrywanie historii wymaga poszukiwania wskazówek w lokalu.

\- «extend» Odkryj nowe składniki – niektóre odkrycia fabularne mogą prowadzić do zdobycia nowych produktów.

\- Wpływa na Eksploruj lokal i zaplecze – poznawanie historii może odblokowywać kolejne obszary do eksploracji.

Częstotliwość użycia: Średnia – odkrywanie historii odbywa się stopniowo podczas rozgrywki.



### 6\. Odkryj nowe składniki

Aktor główny: Gracz



Aktor drugorzędny: Brak



Cel: Zdobywanie i odblokowywanie nowych, nietypowych składników, które rozszerzają możliwości przygotowywania kebabów.



Warunki wstępne

\- Gracz rozpoczął rozgrywkę.

\- Gracz posiada dostęp do eksploracji lokalu.

\- W grze istnieją składniki, które można odblokować poprzez eksplorację lub wykonywanie określonych zadań.

Warunki końcowe (sukces)

\- Nowy składnik zostaje odkryty i odblokowany.

\- System dodaje składnik do listy dostępnych produktów.

\- Gracz może wykorzystać nowy składnik podczas przygotowywania kebabów.

Główny przebieg zdarzeń

1\. Gracz rozpoczyna eksplorację lokalu lub zaplecza.

2\. Gracz poszukuje nowych przedmiotów i składników.

3\. Gracz odnajduje nieznany wcześniej składnik.

4\. Gracz wchodzi w interakcję ze znaleziskiem.

5\. System rozpoznaje znaleziony składnik.

6\. System sprawdza warunki jego odblokowania.

7\. Gracz otrzymuje informację o nowym składniku.

8\. System dodaje składnik do dostępnej listy produktów.

9\. Gracz może wykorzystać nowy składnik w kuchni.

Przebiegi alternatywne

\- 3a. Składnik zostaje odkryty po wykonaniu określonego zadania – system przyznaje dostęp do nowego produktu.

\- 6a. Składnik wymaga dodatkowych warunków – system informuje gracza o konieczności dalszej eksploracji.

\- 8a. Gracz odkrywa kilka nowych składników jednocześnie – wszystkie zostają dodane do listy dostępnych produktów.

Przebiegi wyjątkowe

\- E1. Gracz nie spełnia wymagań odblokowania składnika – system nie udostępnia produktu.

\- E2. Gracz próbuje odblokować składnik, który został już wcześniej odkryty – system informuje o wcześniejszym odblokowaniu.

\- E3. Gracz nie może dotrzeć do miejsca, w którym znajduje się składnik – musi najpierw odblokować dostęp do danego obszaru.

Powiązania z innymi przypadkami użycia

\- «include» Eksploruj lokal i zaplecze – odkrywanie składników jest związane z przeszukiwaniem lokalu.

\- «extend» Odkrywaj historię lokalu – niektóre składniki mogą zostać odblokowane w wyniku odkryć fabularnych.

\- Wpływa na Przygotuj kebaba – nowe składniki zwiększają możliwości tworzenia potraw.

Częstotliwość użycia: Wysoka – odkrywanie nowych składników stanowi jeden z głównych elementów rozwoju rozgrywki.



### Podsumowanie przypadków użycia

Nr	Przypadek użycia	Główny aktor

1	Przyjmij zamówienie	Gracz

2	Przygotuj kebaba	Gracz

3	Wydaj zamówienie	Gracz

4	Eksploruj lokal i zaplecze	Gracz

5	Odkrywaj historię lokalu	Gracz

6	Odkryj nowe składniki	Gracz





Główne powiązania między przypadkami użycia

Najważniejsze relacje w systemie przedstawiają się następująco:

\- Przyjmij zamówienie → Przygotuj kebaba → Wydaj zamówienie – podstawowy cykl rozgrywki związany z obsługą klientów.

\- Eksploruj lokal i zaplecze → Odkryj nowe składniki – eksploracja umożliwia zdobywanie nowych produktów.

\- Eksploruj lokal i zaplecze → Odkrywaj historię lokalu – przeszukiwanie pomieszczeń pozwala poznawać fabułę.

\- Odkrywaj historię lokalu → Odkryj nowe składniki – odkrycia fabularne mogą prowadzić do odblokowania kolejnych składników.

\- Odkryj nowe składniki → Przygotuj kebaba – zdobyte produkty rozszerzają możliwości przygotowywania potraw

